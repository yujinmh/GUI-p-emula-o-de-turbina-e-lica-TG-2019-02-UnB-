.. _apidummyserial:

Documentation for dummy_serial (which is a serial port mock)
======================================================================

.. automodule:: dummy_serial
   :members:
   :undoc-members:




